package client;
import java.net.*;
import java.io.*;

public class client {
	public static void main(String []args) throws Exception{
		Socket client = null;
		ServerSocket server = null;
		PrintStream out = null;
		server = new ServerSocket(10013);
		System.out.println("waiting");
		client = server.accept();
		System.out.println("online");
		BufferedReader buf = null;
		buf = new BufferedReader(new InputStreamReader(client.getInputStream()));
		boolean flag = true;
		while(flag){
			String str = buf.readLine();
			System.out.println(str);
			
			if (str=="bye")
				flag = false;
		}
		buf.close();
		client.close();
		server.close();
	}
}
